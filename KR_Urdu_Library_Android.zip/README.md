# KR Urdu Library — Android Project

Yeh KR Urdu Library web app (`index.html`, `css/`, `js/`, `data/`, `assets/`) ko
bilkul waisa hi, bina kisi tabdeeli ke, ek Android WebView app ke andar
`app/src/main/assets/` mai rakha gaya hai. Sirf Android project ka "system"
structure (manifest, gradle, MainActivity, icons, workflow) upar se add kiya
gaya hai taake iska APK GitHub Actions se ban sake.

`supabase/` folder (edge function + SQL patches) backend/reference code hai —
yeh APK ke andar nahi jata, sirf repo mai reference ke liye rakha hai.

## GitHub se APK kaise banayein
1. Is poore folder ko ek naye GitHub repo mai push karein (`git init && git add . && git commit -m "init" && git push`).
2. GitHub par repo khol kar **Actions** tab mai jayein — "Build APK" workflow
   khud chalegi (push par) ya **Run workflow** button se manually chala sakte hain.
3. Build khatam hone par **Artifacts** section se `app-apk` download karein —
   usme aapki `.apk` file hogi.
4. Package name (`com.krurdulibrary.app`) ya app ka naam badalna ho to
   `.github/workflows/build.yml` mai `APP_ID` aur `APP_NAME` update kar dein.

## Signing key
`krlibrary.jks` ek fixed signing key hai jo is project ke sath commit ki gayi
hai (jaise Docera project mai ki gayi thi), taake har naya build purane APK ke
upar "update" ki tarah install ho, na ke alag app ban jaye. Ise repo se mat
hatayein.

## Notes
- `minSdk = 24` (Android 7.0) se `targetSdk = 36` (Android 16) tak support.
- WebView `file:///android_asset/index.html` load karta hai, JS ES-modules aur
  Supabase network calls ke liye zaroori WebView settings on hain.
- Book PDF "download" button (jo pehle sirf blob link tha) ab
  `AndroidDownloadBridge` ke zariye seedha phone ke **Downloads/KR Urdu Library**
  folder mai save hota hai — yeh add-on hai, app ki original JS files ko chua
  nahi gaya.
