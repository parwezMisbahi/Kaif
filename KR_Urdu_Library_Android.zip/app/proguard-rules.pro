# Add project specific ProGuard rules here.
-keep class com.krurdulibrary.app.MainActivity$AndroidDownloadBridge { *; }
