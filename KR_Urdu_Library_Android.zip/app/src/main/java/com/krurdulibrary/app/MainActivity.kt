package com.krurdulibrary.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val clipData = result.data?.clipData
            if (clipData != null && clipData.itemCount > 0) {
                Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
            } else {
                result.data?.data?.let { arrayOf(it) }
            }
        } else {
            null
        }
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                useWideViewPort = true
                loadWithOverviewMode = true
                mediaPlaybackRequiresUserGesture = false
                // The app loads its JS as ES modules (type="module") from file:// and
                // talks to Supabase — both need these two flags under file:// origin.
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = false
                }
            }

            webViewClient = object : WebViewClient() {}

            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    try {
                        filePickerLauncher.launch(intent)
                    } catch (e: Exception) {
                        this@MainActivity.filePathCallback?.onReceiveValue(null)
                        this@MainActivity.filePathCallback = null
                        return false
                    }
                    return true
                }
            }

            // Lets the page's book-download flow (blob: PDF) save straight into the
            // device's Downloads folder, since a plain <a download> click on a blob:
            // URL does nothing inside a WebView.
            addJavascriptInterface(AndroidDownloadBridge(), "AndroidDownloadBridge")

            loadUrl("file:///android_asset/index.html")
        }

        setContentView(webView)

        // After every page load, hand blob: PDF downloads to the native bridge above
        // instead of the inert <a download> click, without touching any app source file.
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(DOWNLOAD_HOOK_JS, null)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidDownloadBridge")
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    inner class AndroidDownloadBridge {
        /** Saves a base64-encoded PDF into the device's public Downloads folder. */
        @JavascriptInterface
        fun saveBase64Pdf(base64Data: String, filename: String) {
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val safeName = if (filename.isBlank()) "KR Urdu Library Book.pdf" else filename
                val resolver = contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/KR Urdu Library")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                }
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Files.getContentUri("external")
                }
                val uri = resolver.insert(collection, values) ?: return
                resolver.openOutputStream(uri)?.use { it.write(bytes) }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
            } catch (_: Exception) {
                // Best-effort: a failed native save silently falls back to nothing;
                // the in-page download UI already showed the attempt to the user.
            }
        }
    }

    companion object {
        // Intercepts clicks on the app's own <a download href="blob:...">/<a download
        // href="data:..."> links (created by js/features/download-manager.js) and routes
        // them to AndroidDownloadBridge so the PDF actually lands in Downloads.
        private const val DOWNLOAD_HOOK_JS = """
        (function() {
          if (window.__krDownloadHookInstalled) return;
          window.__krDownloadHookInstalled = true;
          document.addEventListener('click', function(e) {
            var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
            if (!a || !a.href) return;
            if (a.href.indexOf('blob:') !== 0 && a.href.indexOf('data:') !== 0) return;
            e.preventDefault();
            var filename = a.getAttribute('download') || 'KR Urdu Library Book.pdf';
            fetch(a.href).then(function(r) { return r.blob(); }).then(function(blob) {
              var reader = new FileReader();
              reader.onloadend = function() {
                var base64 = String(reader.result).split(',')[1] || '';
                if (window.AndroidDownloadBridge && base64) {
                  window.AndroidDownloadBridge.saveBase64Pdf(base64, filename);
                }
              };
              reader.readAsDataURL(blob);
            }).catch(function() {});
          }, true);
        })();
        """
    }
}
