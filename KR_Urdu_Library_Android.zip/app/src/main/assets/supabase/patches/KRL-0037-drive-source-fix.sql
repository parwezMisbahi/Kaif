-- KR Urdu Library — KRL-0037 Drive source normalization
-- Restore/import patch only. The live row has already been normalized.
UPDATE public.books
SET pdf_source_type = 'drive',
    drive_file_id = '1VTQ_7VDoRdagcD9CtRJJ9pjoeGvqpeAD'
WHERE id = 'KRL-0037';
