KR Urdu Library — R7 AbortError + KRL-0033 Source Fix

Base: R7_ABORTERROR_READER_FIXED

The KRL-0033 PDF source was changed to a Range-compatible Archive.org copy.
The live Supabase database has already been updated. The included SQL patch is for restoring the same catalogue change elsewhere.

No R1-R7 reader/gateway protections were removed.
