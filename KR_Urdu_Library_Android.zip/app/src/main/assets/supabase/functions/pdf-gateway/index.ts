import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS={
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"authorization, apikey, x-client-info, x-kr-client, content-type, range, if-range, if-none-match, if-modified-since",
  "Access-Control-Allow-Methods":"GET, HEAD, OPTIONS",
  "Access-Control-Expose-Headers":"Accept-Ranges, Content-Length, Content-Range, Content-Type, Content-Disposition, ETag, Last-Modified, X-KR-PDF-Range-Error"
};
const CLIENT_MARKER="KR-URDU-LIBRARY-PDF-V1";
const ALLOWED_HOSTS=["archive.org","google.com","googleusercontent.com"];

function cors(h=new Headers()){for(const [k,v] of Object.entries(CORS))h.set(k,v);return h}
function allowedHost(hostname:string){
  const h=hostname.toLowerCase().replace(/\.$/,"");
  return ALLOWED_HOSTS.some(base=>h===base||h.endsWith(`.${base}`));
}
function pdfType(v:string|null){
  if(!v)return false;
  v=v.toLowerCase();
  return v.includes("application/pdf")||v.includes("application/octet-stream");
}
function driveUrl(id:string){return `https://drive.google.com/uc?export=download&id=${encodeURIComponent(id)}`}
function driveFileIdFromUrl(value:string){
  try{
    const u=new URL(value);
    if(!allowedHost(u.hostname))return null;
    const host=u.hostname.toLowerCase();
    if(host!=="drive.google.com" && !host.endsWith(".google.com"))return null;
    const fileMatch=u.pathname.match(/^\/file\/d\/([A-Za-z0-9_-]+)/i);
    if(fileMatch)return fileMatch[1];
    const queryId=u.searchParams.get("id");
    if(queryId && /^[A-Za-z0-9_-]{1,200}$/.test(queryId))return queryId;
  }catch{}
  return null;
}
function safeFilename(value:string){
  return (value||"KR Urdu Library Book")
    .replace(/[\\/:*?"<>|]/g," ")
    .replace(/\s+/g," ")
    .trim()
    .replace(/[. ]+$/,"")
    .slice(0,180) || "KR Urdu Library Book";
}
async function fetchSource(initial:string,headers:Headers,method:string){
  let current=new URL(initial);
  for(let i=0;i<6;i++){
    if(current.protocol!=="https:"||!allowedHost(current.hostname))throw new Error("Source host is not allowed");
    const c=new AbortController(),timer=setTimeout(()=>c.abort(),25000);
    let r:Response;
    try{r=await fetch(current,{method,headers,redirect:"manual",signal:c.signal})}
    finally{clearTimeout(timer)}
    if([301,302,303,307,308].includes(r.status)){
      const loc=r.headers.get("location"); if(!loc)throw new Error("Redirect without location");
      current=new URL(loc,current); continue
    }
    return r
  }
  throw new Error("Too many redirects")
}

Deno.serve(async(req:Request)=>{
  if(req.method==="OPTIONS")return new Response(null,{status:204,headers:cors()});
  if(req.method!=="GET"&&req.method!=="HEAD")return new Response("Method not allowed",{status:405,headers:cors(new Headers({Allow:"GET, HEAD, OPTIONS"}))});

  try{
    const u=new URL(req.url);
    const client=req.headers.get("x-kr-client")||u.searchParams.get("client");
    if(client!==CLIENT_MARKER)return new Response("Invalid client",{status:403,headers:cors()});

    const bookId=u.searchParams.get("book_id")?.trim();
    if(!bookId||!/^[A-Za-z0-9_-]{1,100}$/.test(bookId))
      return new Response("Missing or invalid book_id",{status:400,headers:cors()});

    const supabaseUrl=Deno.env.get("SUPABASE_URL"),anonKey=Deno.env.get("SUPABASE_ANON_KEY");
    if(!supabaseUrl||!anonKey)throw new Error("Supabase environment unavailable");

    const supabase=createClient(supabaseUrl,anonKey);
    const {data:book,error}=await supabase
      .from("books")
      .select("id,title,title_en,pdf_url,pdf_source_type,drive_file_id,status")
      .eq("id",bookId)
      .eq("status","available")
      .maybeSingle();

    if(error)throw error;
    if(!book)return new Response("Book not found",{status:404,headers:cors()});

    let source:string|null=null;
    if(book.pdf_source_type==="drive"){
      if(!book.drive_file_id)return new Response("Drive file is not configured",{status:422,headers:cors()});
      source=driveUrl(book.drive_file_id);
    }else if(book.pdf_url){
      // Accept a legacy/misconfigured Drive /file/{id}/view URL as a Drive
      // source too. This keeps the fallback reader resilient while source
      // metadata is being normalized in the library data.
      const driveId=driveFileIdFromUrl(book.pdf_url);
      source=driveId ? driveUrl(driveId) : book.pdf_url;
    }
    if(!source)return new Response("PDF source is not configured",{status:422,headers:cors()});

    const sourceUrl=new URL(source);
    if(sourceUrl.protocol!=="https:"||!allowedHost(sourceUrl.hostname))
      return new Response("PDF source host is not approved",{status:403,headers:cors()});

    const uh=new Headers({
      Accept:"application/pdf,application/octet-stream;q=0.9,*/*;q=0.1"
    });
    for(const n of ["range","if-range","if-none-match","if-modified-since"]){
      const v=req.headers.get(n);if(v)uh.set(n,v);
    }

    const requestedRange=req.headers.get("range");
    const rangeRequested=Boolean(requestedRange);
    const shouldDownload=u.searchParams.get("download")==="1";

    const upstream=await fetchSource(sourceUrl.toString(),uh,req.method);
    if(upstream.status===304)return new Response(null,{status:304,headers:cors(new Headers(upstream.headers))});
    if(!upstream.ok&&upstream.status!==206)
      return new Response(`Upstream PDF source returned ${upstream.status}`,{status:502,headers:cors()});
    if(!pdfType(upstream.headers.get("content-type")))
      return new Response("Upstream did not return a PDF file",{status:502,headers:cors()});

    // Reader requests must never silently receive a full-file 200 response
    // when the client explicitly asked for a byte range. Otherwise a source
    // that ignores Range could make a 500 MB book look like a normal reader
    // request and transfer the entire file. Explicit downloads are allowed to
    // use a normal 200 response because they intentionally fetch the whole PDF.
    if(rangeRequested&&!shouldDownload&&upstream.status===200){
      return new Response("PDF source ignored the requested byte range",{
        status:502,
        headers:cors(new Headers({"X-KR-PDF-Range-Error":"upstream-range-ignored"}))
      });
    }

    if(rangeRequested&&!shouldDownload&&upstream.status!==206){
      return new Response("PDF source did not return a partial response",{
        status:502,
        headers:cors(new Headers({"X-KR-PDF-Range-Error":"invalid-partial-response"}))
      });
    }

    if(rangeRequested&&!shouldDownload&&upstream.status===206){
      const contentRange=upstream.headers.get("content-range")?.trim()||"";
      const match=/^bytes\s+(\d+)-(\d+)\/(\d+|\*)$/i.exec(contentRange);
      if(!match){
        return new Response("PDF source returned an invalid Content-Range",{
          status:502,
          headers:cors(new Headers({"X-KR-PDF-Range-Error":"invalid-content-range"}))
        });
      }

      const start=Number(match[1]),end=Number(match[2]);
      const total=match[3]==="*"?null:Number(match[3]);
      const expectedLength=end-start+1;
      const contentLength=upstream.headers.get("content-length");

      if(end<start||(total!==null&&(total<=end||total<=0))){
        return new Response("PDF source returned an impossible Content-Range",{
          status:502,
          headers:cors(new Headers({"X-KR-PDF-Range-Error":"impossible-content-range"}))
        });
      }

      if(contentLength!==null){
        const length=Number(contentLength);
        if(!Number.isSafeInteger(length)||length!==expectedLength){
          return new Response("PDF source returned a mismatched Content-Length for the requested range",{
            status:502,
            headers:cors(new Headers({"X-KR-PDF-Range-Error":"content-length-mismatch"}))
          });
        }
      }
    }

    const requestedFilename=u.searchParams.get("filename");
    const filename=safeFilename(requestedFilename||book.title_en||book.title||"KR Urdu Library Book");

    const out=new Headers({
      "Content-Type":"application/pdf",
      "Content-Disposition":`${shouldDownload?"attachment":"inline"}; filename="${filename}.pdf"`,
      // Reader responses may be cached by the browser, but must not be shared
      // by intermediary/public caches. This avoids cross-user range mixing
      // while still allowing repeat reader requests to reuse cached bytes.
      "Cache-Control":shouldDownload
        ? "private, no-store"
        : "private, max-age=300, must-revalidate"
    });
    for(const n of ["content-length","content-range","etag","last-modified","accept-ranges"]){
      const v=upstream.headers.get(n);if(v)out.set(n,v);
    }
    cors(out);
    return new Response(req.method==="HEAD"?null:upstream.body,{status:upstream.status,headers:out});
  }catch(err){
    console.error("pdf-gateway",err);
    return new Response("Unable to load PDF from source",{status:502,headers:cors()});
  }
});
