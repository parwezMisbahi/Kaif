import { supabase } from './supabase.js';
import { searchBooks, normalize } from '../features/search.js';

let cache = null;
const COVER_BUCKET = 'covers';
const PERSISTENT_CACHE_KEY = 'kr-urdu-library-catalogue-v1';
const PERSISTENT_CACHE_VERSION = 6;
const LEGACY_PERSISTENT_CACHE_VERSIONS = new Set([2, 3, 5]);
const PERSISTENT_CACHE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

// Resolves a stored cover_path to a directly-fetchable Supabase Storage URL.
// - Already-absolute URLs (new records, saved by the Manager) pass through unchanged.
// - Legacy relative paths (old records saved before covers were uploaded to Storage) are
//   resolved by filename against the same public "covers" bucket the Manager uploads to.
function resolveCoverUrl(coverPath) {
  if (!coverPath) return '';
  if (/^https?:\/\//i.test(coverPath)) return coverPath;
  const fileName = coverPath.split('/').pop();
  if (!fileName) return '';
  try {
    const { data } = supabase.storage.from(COVER_BUCKET).getPublicUrl(fileName);
    return data?.publicUrl || '';
  } catch {
    return '';
  }
}

async function fetchJSON(url) {
  const response = await fetch(url, { cache: 'default' });
  if (!response.ok) throw new Error(`Could not load ${url} (${response.status})`);
  const value = await response.json();
  if (!Array.isArray(value)) throw new Error(`Invalid data format: ${url}`);
  return value;
}

function normalizeBooks(books) {
  const seen = new Set();
  return books.filter(book => {
    if (!book || typeof book !== 'object' || !book.id || seen.has(book.id)) return false;
    seen.add(book.id);
    book.categoryIds = Array.isArray(book.categoryIds) ? book.categoryIds : [];
    book.classIds = Array.isArray(book.classIds) ? [...new Set(book.classIds.filter(Boolean))] : (book.classId ? [book.classId] : []);
    if (book.classId && !book.classIds.includes(book.classId)) book.classIds.unshift(book.classId);
    book.keywords = Array.isArray(book.keywords) ? book.keywords : [];
    book.status = ['available', 'review', 'unavailable'].includes(book.status) ? book.status : 'review';
    book.bookType = book.bookType === 'sharah' ? 'sharah' : 'matn';
    book.source = book.source && typeof book.source === 'object' ? book.source : {};
    return true;
  });
}

function normalizeLookup(list) {
  return list.filter(item => item && typeof item === 'object' && item.id);
}

function mapBook(row, categoryIds = [], classIds = []) {
  const normalizedClassIds = Array.isArray(classIds) ? [...new Set(classIds.filter(Boolean))] : [];
  const legacyClassId = row.class_id || '';
  if (legacyClassId && !normalizedClassIds.includes(legacyClassId)) normalizedClassIds.unshift(legacyClassId);
  return {
    id: row.id,
    title: row.title,
    titleEn: row.title_en || '',
    author: row.author || '',
    description: row.description || '',
    classId: normalizedClassIds[0] || legacyClassId,
    classIds: normalizedClassIds,
    bookType: row.book_type || 'matn',
    pages: row.pages ?? null,
    cover: resolveCoverUrl(row.cover_path),
    pdfUrl: row.pdf_url || '',
    pdfSourceType: row.pdf_source_type || 'external',
    driveFileId: row.drive_file_id || '',
    source: { name: row.source_name || '', pageUrl: row.source_page_url || '' },
    status: row.status || 'review',
    keywords: Array.isArray(row.keywords) ? row.keywords : [],
    categoryIds,
    addedAt: row.added_at || row.created_at || '',
    createdAt: row.created_at || row.added_at || ''
  };
}


function buildLibraryIndexes(library) {
  const byId = new Map();
  const byClass = new Map();
  const byCategory = new Map();
  const recentBooks = [...library.books].sort((a,b) => String(b.addedAt).localeCompare(String(a.addedAt)));

  library.books.forEach(book => {
    byId.set(book.id, book);
    const classIds = Array.isArray(book.classIds) && book.classIds.length ? book.classIds : (book.classId ? [book.classId] : []);
    classIds.forEach(classId => {
      if (!byClass.has(classId)) byClass.set(classId, []);
      byClass.get(classId).push(book);
    });
    (book.categoryIds || []).forEach(categoryId => {
      if (!byCategory.has(categoryId)) byCategory.set(categoryId, []);
      byCategory.get(categoryId).push(book);
    });
  });

  return Object.assign(library, { byId, byClass, byCategory, recentBooks });
}

const BOOK_PAGE_SIZE = 20;
let paging = { nextOffset: 0, done: false, loading: null, cursor: null };
let classStats = null;
let classStatsLoading = null;


async function fetchBookPageFromSupabase(offset, size = BOOK_PAGE_SIZE, cursor = null) {
  let query = supabase.from('books')
    .select('id,title,title_en,author,description,class_id,book_type,pages,cover_path,pdf_url,source_name,source_page_url,pdf_source_type,drive_file_id,status,keywords,added_at,created_at')
    .order('added_at', { ascending: false })
    .order('created_at', { ascending: false })
    .order('id', { ascending: false });

  // Keyset pagination keeps a stable catalogue boundary while new books are
  // inserted during a session. Offset pagination can skip rows when the
  // catalogue changes between requests. The first page establishes a cursor;
  // later pages only read rows after that cursor in the same ordering.
  if (cursor?.addedAt && cursor?.createdAt && cursor?.id) {
    const a = String(cursor.addedAt).replace(/[(),]/g, ' ');
    const c = String(cursor.createdAt).replace(/[(),]/g, ' ');
    const id = String(cursor.id).replace(/[(),]/g, ' ');
    query = query.or(`added_at.lt.${a},and(added_at.eq.${a},created_at.lt.${c}),and(added_at.eq.${a},created_at.eq.${c},id.lt.${id})`);
    query = query.limit(size);
  } else {
    query = query.range(offset, offset + size - 1);
  }

  const booksRes = await query;
  if (booksRes.error) throw booksRes.error;
  const ids = (booksRes.data || []).map(row => row.id);
  const categoryMap = new Map();
  const classMap = new Map();
  if(ids.length){
    const [categoriesRes, classesRes] = await Promise.all([
      supabase.from('book_categories').select('book_id,category_id').in('book_id', ids),
      supabase.from('book_classes').select('book_id,class_id').in('book_id', ids)
    ]);
    if (categoriesRes.error) throw categoriesRes.error;
    if (classesRes.error) throw classesRes.error;
    (categoriesRes.data || []).forEach(row => {
      if (!categoryMap.has(row.book_id)) categoryMap.set(row.book_id, []);
      categoryMap.get(row.book_id).push(row.category_id);
    });
    (classesRes.data || []).forEach(row => {
      if (!classMap.has(row.book_id)) classMap.set(row.book_id, []);
      classMap.get(row.book_id).push(row.class_id);
    });
  }
  return (booksRes.data || []).map(row => mapBook(row, categoryMap.get(row.id) || [], classMap.get(row.id) || []));
}

function readPersistentCache({ allowStale = false } = {}) {
  try {
    const raw = localStorage.getItem(PERSISTENT_CACHE_KEY);
    if (!raw) return null;
    const saved = JSON.parse(raw);
    if (!saved || !Array.isArray(saved.books)) return null;
    const version = Number(saved.version);
    if (version !== PERSISTENT_CACHE_VERSION && !LEGACY_PERSISTENT_CACHE_VERSIONS.has(version)) return null;
    const age = saved.savedAt ? Math.max(0, Date.now() - Number(saved.savedAt)) : Infinity;
    if (!allowStale && age > PERSISTENT_CACHE_MAX_AGE_MS) return null;
    return { ...saved, version: PERSISTENT_CACHE_VERSION, stale: age > PERSISTENT_CACHE_MAX_AGE_MS, migratedFrom: version !== PERSISTENT_CACHE_VERSION ? version : null };
  } catch {
    return null;
  }
}

let persistentWriteTimer = null;

function writePersistentCache(library, { immediate = false } = {}) {
  const save = () => {
    try {
      localStorage.setItem(PERSISTENT_CACHE_KEY, JSON.stringify({
        version: PERSISTENT_CACHE_VERSION,
        savedAt: Date.now(),
        booksComplete: Boolean(paging.done),
        books: library.books,
        classes: library.classes,
        categories: library.categories,
        classStats: classStats && typeof classStats === 'object' ? classStats : null,
        paginationCursor: paging.cursor || null
      }));
    } catch (error) {
      // Storage can be full or unavailable in private/WebView contexts. The in-memory cache still works.
      console.warn('KR Urdu Library persistent catalogue cache unavailable.', error);
    }
  };
  if (persistentWriteTimer) clearTimeout(persistentWriteTimer);
  if (immediate) save();
  else persistentWriteTimer = setTimeout(() => { persistentWriteTimer = null; save(); }, 250);
}

function flushPersistentCache() {
  if (!persistentWriteTimer || !cache) return;
  clearTimeout(persistentWriteTimer);
  persistentWriteTimer = null;
  writePersistentCache(cache, { immediate: true });
}

function clearPersistentCache() {
  if (persistentWriteTimer) { clearTimeout(persistentWriteTimer); persistentWriteTimer = null; }
  try { localStorage.removeItem(PERSISTENT_CACHE_KEY); } catch {}
}

if (typeof window !== 'undefined') window.addEventListener('pagehide', flushPersistentCache);

function loadFromPersistentCache({ allowStale = false } = {}) {
  const saved = readPersistentCache({ allowStale });
  if (!saved) return null;
  const books = normalizeBooks(saved.books || []);
  if (!books.length) return null;
  paging = {
    nextOffset: books.length,
    done: Boolean(saved.booksComplete),
    loading: null,
    cursor: saved.paginationCursor && typeof saved.paginationCursor === 'object' ? saved.paginationCursor : null
  };
  const library = buildLibraryIndexes({
    books,
    classes: normalizeLookup(saved.classes || []),
    categories: normalizeLookup(saved.categories || [])
  });
  classStats = saved.classStats && typeof saved.classStats === 'object' ? saved.classStats : null;
  library.source = 'persistent-cache';
  library.cacheStale = Boolean(saved.stale);
  if (saved.migratedFrom) writePersistentCache(library, { immediate: true });
  return library;
}

async function loadFromSupabase() {
  const [firstBooks, classesRes, categoriesRes] = await Promise.all([
    fetchBookPageFromSupabase(0),
    supabase.from('classes').select('id,name_ur,name_en,sort_order').eq('is_active', true).order('sort_order', { ascending: true }),
    supabase.from('categories').select('id,name_ur,name_en,sort_order').eq('is_active', true).order('sort_order', { ascending: true })
  ]);
  for (const result of [classesRes, categoriesRes]) {
    if (result.error) throw result.error;
  }
  const firstLast = firstBooks[firstBooks.length - 1];
  paging = {
    nextOffset: firstBooks.length,
    done: firstBooks.length < BOOK_PAGE_SIZE,
    loading: null,
    cursor: firstLast ? { addedAt: firstLast.addedAt, createdAt: firstLast.createdAt, id: firstLast.id } : null
  };
  classStats = null;
  classStatsLoading = null;
  const library = buildLibraryIndexes({
    books: normalizeBooks(firstBooks),
    classes: normalizeLookup((classesRes.data || []).map(c => ({ id:c.id, name:c.name_ur, nameEn:c.name_en, sortOrder:c.sort_order }))),
    categories: normalizeLookup((categoriesRes.data || []).map(c => ({ id:c.id, name:c.name_ur, nameEn:c.name_en, sortOrder:c.sort_order })))
  });
  library.source = 'supabase';
  library.cacheStale = false;
  writePersistentCache(library, { immediate: true });
  return library;
}

async function loadLocalFallback() {
  const [books, classes, categories] = await Promise.all([
    fetchJSON('./data/books.json'), fetchJSON('./data/classes.json'), fetchJSON('./data/categories.json')
  ]);
  paging = { nextOffset: books.length, done: true, loading: null, cursor: null };
  const library = buildLibraryIndexes({ books: normalizeBooks(books), classes: normalizeLookup(classes), categories: normalizeLookup(categories) });
  writePersistentCache(library, { immediate: true });
  return library;
}


async function fetchClassStatsFromSupabase(classes = []) {
  const activeClasses = normalizeLookup(classes);
  if (!activeClasses.length) return {};
  const classIds = activeClasses.map(c => c.id);
  const mappingsRes = await supabase
    .from('book_classes')
    .select('class_id,book_id,books!inner(book_type)')
    .in('class_id', classIds);
  if (mappingsRes.error) throw mappingsRes.error;
  const stats = Object.fromEntries(classIds.map(id => [id, { total: 0, matn: 0, sharah: 0 }]));
  (mappingsRes.data || []).forEach(row => {
    const stat = stats[row.class_id];
    if (!stat) return;
    stat.total += 1;
    const type = row.books?.book_type;
    if (type === 'matn') stat.matn += 1;
    else if (type === 'sharah') stat.sharah += 1;
  });
  return stats;
}

export async function loadClassStats({ force = false } = {}) {
  if (!cache) await loadLibraryData();
  if (!force && classStats && typeof classStats === 'object') return classStats;
  if (classStatsLoading) return classStatsLoading;

  // A complete local catalogue is authoritative enough to calculate these stats
  // without another network round-trip (local fallback or fully paginated cache).
  if (!force && paging.done) {
    const calculated = {};
    cache.classes.forEach(c => {
      const books = cache.byClass?.get(c.id) || [];
      calculated[c.id] = {
        total: books.length,
        matn: books.filter(b => b.bookType === 'matn').length,
        sharah: books.filter(b => b.bookType === 'sharah').length
      };
    });
    classStats = calculated;
    writePersistentCache(cache, { immediate: true });
    return classStats;
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return null;
  }

  classStatsLoading = (async () => {
    try {
      classStats = await fetchClassStatsFromSupabase(cache.classes);
      writePersistentCache(cache, { immediate: true });
      return classStats;
    } finally {
      classStatsLoading = null;
    }
  })();
  return classStatsLoading;
}


const SEARCH_CANDIDATE_PAGE_SIZE = 100;
let searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: 0 };
let searchGeneration = 0;

function escapeIlike(value = '') {
  return String(value).replace(/[\\%_(),]/g, ' ').replace(/\s+/g, ' ').trim();
}

function escapePgArrayElement(value = '') {
  return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

function buildSearchOr(tokens) {
  const fields = ['title','title_en','author','description'];
  const clauses = [];
  tokens.forEach(token => {
    const safe = escapeIlike(token);
    fields.forEach(field => clauses.push(`${field}.ilike.%${safe}%`));
    // PostgreSQL array containment needs a valid array literal. Quoting and
    // escaping the token prevents commas/braces/quotes in user input from
    // changing the PostgREST filter expression.
    const keyword = escapePgArrayElement(safe);
    clauses.push(`keywords.cs.{"${keyword}"}`);
  });
  return clauses.join(',');
}

function resetSearchPaging(query) {
  const normalized = String(query || '').trim();
  if (searchPaging.query === normalized) return;
  searchPaging = { query: normalized, offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
}

export async function searchBooksPage(query, { pageSize = 20 } = {}) {
  const normalized = normalize(query || '');
  if (searchPaging.generation !== searchGeneration) searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
  resetSearchPaging(normalized);
  if (!normalized) return { results: [], done: true, totalLoaded: 0 };
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    const offlineError = new Error('Offline: using cached search results.');
    offlineError.code = 'OFFLINE';
    offlineError.retryable = false;
    throw offlineError;
  }
  if (searchPaging.done && searchPaging.pending.length === 0) {
    return { results: [], done: true, totalLoaded: searchPaging.seen.size };
  }
  if (searchPaging.loading) return searchPaging.loading;

  const tokens = normalized.split(/\s+/).filter(Boolean);
  searchPaging.loading = (async () => {
    try {
      // Drain already-fetched candidates before asking Supabase for another page.
      // This prevents the old bug where candidates 21-100 were marked as seen
      // but never returned because only the first 20 were exposed to the UI.
      const results = searchPaging.pending.splice(0, pageSize);
      if (results.length >= pageSize || (searchPaging.done && searchPaging.pending.length === 0)) {
        return {
          results,
          done: searchPaging.done && searchPaging.pending.length === 0,
          totalLoaded: searchPaging.seen.size
        };
      }

      while (results.length < pageSize && !searchPaging.done) {
        const from = searchPaging.offset;
        const to = from + SEARCH_CANDIDATE_PAGE_SIZE - 1;
        const res = await supabase.from('books')
          .select('id,title,title_en,author,description,class_id,book_type,pages,cover_path,pdf_url,source_name,source_page_url,pdf_source_type,drive_file_id,status,keywords,added_at,created_at')
          .or(buildSearchOr(tokens))
          .order('added_at', { ascending: false })
          .order('created_at', { ascending: false })
          .order('id', { ascending: false })
          .range(from, to);
        if (res.error) throw res.error;
        const rows = res.data || [];
        searchPaging.offset += rows.length;
        if (rows.length < SEARCH_CANDIDATE_PAGE_SIZE) searchPaging.done = true;
        if (!rows.length) break;

        const ids = rows.map(row => row.id);
        const categoryMap = new Map();
        const classMap = new Map();
        if (ids.length) {
          const [categoriesRes, classesRes] = await Promise.all([
            supabase.from('book_categories').select('book_id,category_id').in('book_id', ids),
            supabase.from('book_classes').select('book_id,class_id').in('book_id', ids)
          ]);
          if (categoriesRes.error) throw categoriesRes.error;
          if (classesRes.error) throw classesRes.error;
          (categoriesRes.data || []).forEach(row => {
            if (!categoryMap.has(row.book_id)) categoryMap.set(row.book_id, []);
            categoryMap.get(row.book_id).push(row.category_id);
          });
          (classesRes.data || []).forEach(row => {
            if (!classMap.has(row.book_id)) classMap.set(row.book_id, []);
            classMap.get(row.book_id).push(row.class_id);
          });
        }
        const books = rows.map(row => mapBook(row, categoryMap.get(row.id) || [], classMap.get(row.id) || []));
        const normalizedBooks = normalizeBooks(books);
        // Server filtering is intentionally broad (OR across searchable fields)
        // so pagination can find every candidate. Apply the canonical local matcher
        // before exposing results; this makes online search use the same AND/token
        // semantics as offline search instead of returning OR-only matches.
        const localMatches = searchBooks(normalizedBooks, normalized).filter(book => {
          if (searchPaging.seen.has(book.id)) return false;
          searchPaging.seen.add(book.id);
          return true;
        });
        searchPaging.pending.push(...localMatches);

        const remaining = pageSize - results.length;
        if (remaining > 0 && searchPaging.pending.length) {
          results.push(...searchPaging.pending.splice(0, remaining));
        }
      }
      return {
        results,
        done: searchPaging.done && searchPaging.pending.length === 0,
        totalLoaded: searchPaging.seen.size
      };
    } finally {
      searchPaging.loading = null;
    }
  })();
  return searchPaging.loading;
}


export function mergeBooksIntoLibrary(books = []) {
  if (!cache || !Array.isArray(books) || !books.length) return cache;
  const normalized = normalizeBooks(books);
  if (!normalized.length) return cache;

  // Upsert by stable book id instead of append-only merging. A Manager edit
  // must replace the cached metadata immediately; otherwise an edited title,
  // cover, source, status, or class/category mapping can remain stale until
  // the user performs a full refresh.
  const byId = new Map(cache.books.map(book => [book.id, book]));
  let changed = false;
  normalized.forEach(book => {
    const previous = byId.get(book.id);
    if (!previous || JSON.stringify(previous) !== JSON.stringify(book)) changed = true;
    byId.set(book.id, book);
  });
  if (!changed) return cache;

  cache.books = [...byId.values()];
  buildLibraryIndexes(cache);
  writePersistentCache(cache);
  return cache;
}

export async function loadNextBookPage() {
  if (!cache || paging.done) return { data: cache, added: [], done: true };
  if (paging.loading) return paging.loading;
  const offset = paging.nextOffset;
  const cursor = paging.cursor;
  paging.loading = (async () => {
    try {
      const added = normalizeBooks(await fetchBookPageFromSupabase(offset, BOOK_PAGE_SIZE, cursor));
      const before = new Map(cache.books.map(book => [book.id, book]));
      let changed = false;
      added.forEach(book => {
        const previous = before.get(book.id);
        if (!previous) changed = true;
        else if (JSON.stringify(previous) !== JSON.stringify(book)) changed = true;
        before.set(book.id, book);
      });
      cache.books = [...before.values()];
      buildLibraryIndexes(cache);
      paging.nextOffset += added.length;
      if (added.length) {
        const last = added[added.length - 1];
        paging.cursor = { addedAt: last.addedAt, createdAt: last.createdAt, id: last.id };
      }
      paging.done = added.length < BOOK_PAGE_SIZE || added.length === 0;
      if (changed) writePersistentCache(cache);
      return { data: cache, added, done: paging.done };
    } finally {
      paging.loading = null;
    }
  })();
  return paging.loading;
}

export async function ensureAllBooksLoaded() {
  if (!cache) await loadLibraryData();
  while (!paging.done) await loadNextBookPage();
  return cache;
}

export function clearLibraryCache({ persistent = true } = {}) {
  cache = null;
  classStats = null;
  classStatsLoading = null;
  searchGeneration += 1;
  searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
  paging = { nextOffset: 0, done: false, loading: null, cursor: null };
  if (persistent) clearPersistentCache();
}

export function getLibraryCacheInfo() {
  if (!cache) return { source: 'none', stale: false, books: 0, complete: false };
  return { source: cache.source || 'memory', stale: Boolean(cache.cacheStale), books: cache.books?.length || 0, complete: Boolean(paging.done) };
}

export async function loadLibraryData(options = {}) {
  const force = Boolean(options?.force);
  const offline = typeof navigator !== 'undefined' && navigator.onLine === false;
  if (cache && !force) return cache;

  // Offline refresh should be instant: there is no useful network request to
  // wait for. Keep the last known-good persistent snapshot and allow stale data.
  // This also avoids a needless timeout/spinner on Android WebView.
  if (offline) {
    const offlinePersisted = loadFromPersistentCache({ allowStale: true });
    if (offlinePersisted) {
      cache = offlinePersisted;
      return cache;
    }
  }

  // A refresh must never destroy the last known-good persistent cache before the
  // network request succeeds. This is critical for offline/unstable WebViews.
  if (force) clearLibraryCache({ persistent: false });

  const persisted = loadFromPersistentCache({ allowStale: offline });
  if (persisted && !force) {
    cache = persisted;
    return cache;
  }

  try {
    cache = await loadFromSupabase();
    cache.cacheStale = false;
    return cache;
  } catch (error) {
    console.warn('Supabase catalogue unavailable; recovering from persistent/local cache.', error);
    const recovered = loadFromPersistentCache({ allowStale: true });
    if (recovered) {
      cache = recovered;
      return cache;
    }
    cache = await loadLocalFallback();
    cache.source = 'local-fallback';
    cache.cacheStale = false;
    return cache;
  }
}
