import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

export const SUPABASE_URL = 'https://nyjtwqhcwxnxzerimsch.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_J_J6MS17c6DYSOrJDgOfRg_KbX5bNV6';
export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, storageKey: 'kr-urdu-library-public' }
});
