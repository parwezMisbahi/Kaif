import { getLanguage, getTheme } from "./utils/storage.js";

export const state = {
  language: getLanguage(),
  theme: getTheme(),
  route: "home",
  params: {},
  dataReady: false
};
