const PREFIX = "krul:v1:";
const LIMITS = { history: 50 };

function safeRead(key, fallback) {
  try {
    const value = localStorage.getItem(PREFIX + key);
    if (value === null) return fallback;
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function safeWrite(key, value) {
  try { localStorage.setItem(PREFIX + key, JSON.stringify(value)); return true; }
  catch { return false; }
}

export function getFavorites() {
  const value = safeRead("favorites", []);
  return Array.isArray(value) ? value : [];
}

export function toggleFavorite(id) {
  if (!id) return getFavorites();
  const favorites = new Set(getFavorites());
  favorites.has(id) ? favorites.delete(id) : favorites.add(id);
  const result = [...favorites];
  safeWrite("favorites", result);
  return result;
}

export function isFavorite(id) { return getFavorites().includes(id); }

export function getHistory() {
  const value = safeRead("history", []);
  return Array.isArray(value) ? value : [];
}

export function addHistory(id) {
  if (!id) return getHistory();
  const history = getHistory().filter(x => x !== id);
  history.unshift(id);
  safeWrite("history", history.slice(0, LIMITS.history));
}

export function clearHistory() { safeWrite("history", []); }

export function getProgress() {
  const value = safeRead("progress", {});
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

export function setProgress(id, progress) {
  if (!id || !progress || typeof progress !== "object") return null;
  const all = getProgress();
  all[id] = { ...all[id], ...progress, updatedAt: new Date().toISOString() };
  safeWrite("progress", all);
  return all[id];
}

export function getBookProgress(id) { return getProgress()[id] || null; }

export function clearProgress() { safeWrite("progress", {}); }

export function getTheme() {
  const value = localStorage.getItem(PREFIX + "theme");
  return ["system","light","dark"].includes(value) ? value : "system";
}
export function setTheme(theme) {
  if (!["system","light","dark"].includes(theme)) return false;
  try { localStorage.setItem(PREFIX + "theme", theme); return true; } catch { return false; }
}
export function getLanguage() {
  const value = localStorage.getItem(PREFIX + "language");
  return ["ur","en"].includes(value) ? value : "ur";
}
export function setLanguage(lang) {
  if (!["ur","en"].includes(lang)) return false;
  try { localStorage.setItem(PREFIX + "language", lang); return true; } catch { return false; }
}

