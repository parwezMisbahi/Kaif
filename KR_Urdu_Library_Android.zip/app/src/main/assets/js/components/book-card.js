import { escapeHTML, formatPages } from "../utils/helpers.js";
import { isFavorite, toggleFavorite } from "../utils/storage.js";
import { coverMarkup, wireCover } from "../utils/cover.js";

export function bookCard(book, lang, onOpen) {
  const card = document.createElement("article");
  card.className = "book-card";
  card.tabIndex = 0;
  card.setAttribute("role", "link");
  const title = lang === "ur" ? book.title : (book.titleEn || book.title);
  const type = book.bookType === "matn" ? (lang === "ur" ? "متون" : "Matn") : (lang === "ur" ? "شروحات" : "Commentary");
  const pages = formatPages(book.pages, lang);
  const fav = isFavorite(book.id);
  const favLabel = lang === "ur" ? (fav ? "پسندیدہ سے ہٹائیں" : "پسندیدہ میں شامل کریں") : (fav ? "Remove favorite" : "Add favorite");

  card.innerHTML = `
    <button class="favorite-btn ${fav ? "active" : ""}" aria-label="${favLabel}" aria-pressed="${fav}"><i class="fa-${fav ? "solid" : "regular"} fa-heart"></i></button>
    <div class="book-cover">
      ${coverMarkup(book.cover ? escapeHTML(book.cover) : "")}
    </div>
    <div class="book-info">
      <h3 class="book-title">${escapeHTML(title)}</h3>
      <p class="book-author">${escapeHTML(book.author || "")}</p>
      <div class="book-meta"><span class="pill">${type}</span> ${pages ? ` · ${escapeHTML(pages)}` : ""}</div>
      <div class="status ${book.status === "available" ? "available" : "unavailable"}">
        ${book.status === "available" ? (lang === "ur" ? "<i class=\"fa-solid fa-circle-check\"></i> دستیاب" : "<i class=\"fa-solid fa-circle-check\"></i> Available") : (lang === "ur" ? "<i class=\"fa-solid fa-circle-xmark\"></i> فی الحال دستیاب نہیں" : "<i class=\"fa-solid fa-circle-xmark\"></i> Currently unavailable")}
      </div>
    </div>
  `;
  wireCover(card.querySelector(".book-cover"));
  card.querySelector(".favorite-btn").addEventListener("click", e => {
    e.stopPropagation();
    const result = toggleFavorite(book.id);
    const nowFavorite = Array.isArray(result) ? result.includes(book.id) : Boolean(result);
    const button = e.currentTarget;
    const label = lang === "ur"
      ? (nowFavorite ? "پسندیدہ سے ہٹائیں" : "پسندیدہ میں شامل کریں")
      : (nowFavorite ? "Remove favorite" : "Add favorite");
    button.classList.toggle("active", nowFavorite);
    button.setAttribute("aria-label", label);
    button.setAttribute("aria-pressed", String(nowFavorite));
    const icon = button.querySelector("i");
    if (icon) { icon.classList.toggle("fa-solid", nowFavorite); icon.classList.toggle("fa-regular", !nowFavorite); }
    card.dispatchEvent(new CustomEvent("favoritechange", { bubbles: false, detail: { id: book.id, favorite: nowFavorite } }));
  });
  const openCard = () => onOpen?.("book", book.id);
  card.addEventListener("click", openCard);
  card.addEventListener("keydown", e => {
    if ((e.key === "Enter" || e.key === " ") && e.target === card) { e.preventDefault(); openCard(); }
  });
  return card;
}
