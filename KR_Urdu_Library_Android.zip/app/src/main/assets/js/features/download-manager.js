/*
 * KR Urdu Library — Download Manager
 *
 * Phases 1–3: download orchestration, response metadata, and streaming progress.
 * The manager is intentionally framework-free and SPCK-compatible.
 * Cancellation has an explicit intermediate state so the UI can confirm the abort.
 */

import { cachePdf } from "./pdf-cache.js";

const ACTIVE = new Map();
const RETRYABLE = new Map();
const SUBSCRIBERS = new Set();

export const DOWNLOAD_STATES = Object.freeze({
  IDLE: "idle",
  PREPARING: "preparing",
  DOWNLOADING: "downloading",
  COMPLETING: "completing",
  CANCELLING: "cancelling",
  HANDING_OFF: "handing-off",
  HANDED_OFF: "handed-off",
  COMPLETED: "completed",
  FAILED: "failed",
  CANCELLED: "cancelled"
});

function safeFilename(value){
  return (value || "KR Urdu Library Book")
    .replace(/[\\/:*?"<>|]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/[. ]+$/, "")
    .slice(0, 180) || "KR Urdu Library Book";
}

function buildFilename(book){
  const title = safeFilename(book?.titleEn || book?.title || "KR Urdu Library Book");
  return `${title}.pdf`;
}

function emit(callbacks, state, detail = {}){
  const payload = { state, ...detail };
  try { callbacks?.onStateChange?.(payload); } catch (err) { console.error("Download state callback failed", err); }
  try { callbacks?.[state]?.(payload); } catch (err) { console.error("Download callback failed", err); }
  for(const listener of SUBSCRIBERS){
    try { listener(payload); } catch (err) { console.error("Download subscriber failed", err); }
  }
  return payload;
}

function triggerBlobDownload(blob, filename){
  if(!(blob instanceof Blob) || !blob.size) throw new Error("Empty PDF response");

  const objectUrl = URL.createObjectURL(blob);
  try {
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
  } finally {
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
  }
}

function triggerDirectDownload(url, filename){
  if(!url) throw new Error("Download URL is required");
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
}


function parsePositiveBytes(value){
  const n=Number(value);
  return Number.isFinite(n) && n >= 0 ? n : null;
}

function parseContentRange(value){
  if(!value) return null;
  const match=value.match(/^\s*bytes\s+(\d+)\s*-\s*(\d+)\s*\/\s*(\d+|\*)\s*$/i);
  if(!match) return null;
  const start=Number(match[1]);
  const end=Number(match[2]);
  const total=match[3]==="*" ? null : Number(match[3]);
  if(!Number.isFinite(start) || !Number.isFinite(end) || end < start) return null;
  return {
    start,
    end,
    length:end-start+1,
    total:Number.isFinite(total) ? total : null
  };
}

function readResponseMetadata(response){
  const contentLength=parsePositiveBytes(response.headers.get("content-length"));
  const contentRangeValue=response.headers.get("content-range") || "";
  const contentRange=parseContentRange(contentRangeValue);
  const totalBytes=contentRange?.total ?? contentLength;

  return Object.freeze({
    totalBytes,
    contentLength,
    contentRange,
    contentRangeValue,
    sizeKnown:Number.isFinite(totalBytes),
    contentType:response.headers.get("content-type") || "",
    contentDisposition:response.headers.get("content-disposition") || "",
    acceptRanges:response.headers.get("accept-ranges") || "",
    etag:response.headers.get("etag") || "",
    lastModified:response.headers.get("last-modified") || "",
    contentEncoding:response.headers.get("content-encoding") || "",
    responseStatus:response.status
  });
}

function bytesToMegabytes(bytes){
  if(!Number.isFinite(bytes) || bytes < 0) return null;
  return bytes / (1024 * 1024);
}

function isPdfResponse(metadata){
  const type=String(metadata?.contentType||"").toLowerCase();
  return type.includes("application/pdf") || type.includes("application/octet-stream");
}

function createDownloadError(message, code, retryable = true){
  const error = new Error(message);
  error.code = code;
  error.retryable = retryable;
  return error;
}

function validateFullResponse(metadata){
  // This app starts a full GET. A partial response that does not begin at
  // byte 0 cannot safely be turned into a complete PDF by this client.
  if(metadata?.responseStatus === 206){
    const range = metadata.contentRange;
    if(!range || range.start !== 0 || !Number.isFinite(range.total) || range.length !== range.total){
      throw createDownloadError("The server returned only part of the PDF.", "PARTIAL_RESPONSE", true);
    }
  }
}

class DownloadJob {
  constructor(book, url, options = {}){
    this.book = book;
    this.url = url;
    this.filename = buildFilename(book);
    this.callbacks = options;
    this.controller = new AbortController();
    this.nativeDownload = options.nativeDownload === true;
    this.options = { ...options };
    this.allowLargeFileHandoff = options.allowLargeFileHandoff !== false;
    this.largeFileThresholdBytes = Number.isFinite(options.largeFileThresholdBytes) ? options.largeFileThresholdBytes : (100 * 1024 * 1024);
    this.state = DOWNLOAD_STATES.IDLE;
    this.startedAt = 0;
    this.promise = null;
    this.lastProgress = {};
  }

  setState(state, detail = {}){
    this.state = state;
    this.lastProgress = { ...this.lastProgress, ...detail };
    return emit(this.callbacks, state, {
      bookId: this.book?.id ?? null,
      filename: this.filename,
      ...detail
    });
  }

  async run(){
    this.startedAt = Date.now();
    this.setState(DOWNLOAD_STATES.PREPARING);

    if(this.nativeDownload){
      return this.handOffToBrowser("embedded-webview");
    }

    try {
      const response = await fetch(this.url, {
        method: "GET",
        headers: { "x-kr-client": "KR-URDU-LIBRARY-PDF-V1" },
        signal: this.controller.signal
      });

      if(!response.ok) {
        throw createDownloadError(`Download failed: ${response.status}`, `HTTP_${response.status}`, [408,425,429,500,502,503,504].includes(response.status));
      }

      const metadata = readResponseMetadata(response);
      if(!isPdfResponse(metadata)){
        throw createDownloadError("The download source did not return a PDF file.", "INVALID_CONTENT_TYPE", false);
      }
      validateFullResponse(metadata);

      if(this.allowLargeFileHandoff && metadata.sizeKnown && metadata.totalBytes >= this.largeFileThresholdBytes){
        try { await response.body?.cancel?.(); } catch {}
        return this.handOffToBrowser("large-file", metadata);
      }

      this.setState(DOWNLOAD_STATES.DOWNLOADING, {
        ...metadata,
        totalBytes: metadata.totalBytes,
        downloadedBytes: 0,
        downloadedMegabytes: 0,
        totalMegabytes: bytesToMegabytes(metadata.totalBytes)
      });

      const blob = await this.readResponse(response, metadata);
      if(this.state === DOWNLOAD_STATES.CANCELLING || this.controller.signal.aborted){
        const result = { ok: false, state: DOWNLOAD_STATES.CANCELLED, bookId: this.book?.id ?? null, filename: this.filename, ...this.lastProgress };
        this.setState(DOWNLOAD_STATES.CANCELLED, result);
        return result;
      }
      if(!blob.size) throw createDownloadError("Empty PDF response", "EMPTY_RESPONSE", true);

      // Never report success for a truncated response. This is especially
      // important on mobile networks where a connection can end cleanly
      // before the advertised Content-Length is received.
      if(metadata.sizeKnown && !metadata.contentEncoding && blob.size !== metadata.totalBytes){
        throw createDownloadError("The PDF download was incomplete. Please try again.", "INCOMPLETE_RESPONSE", true);
      }

      const finalTotalBytes = metadata.sizeKnown ? metadata.totalBytes : blob.size;
      this.setState(DOWNLOAD_STATES.COMPLETING, {
        downloadedBytes: blob.size,
        totalBytes: finalTotalBytes,
        downloadedMegabytes: bytesToMegabytes(blob.size),
        totalMegabytes: bytesToMegabytes(finalTotalBytes),
        percentage: finalTotalBytes ? Math.min(100, (blob.size / finalTotalBytes) * 100) : null
      });

      // Start the browser save immediately. Offline caching is best-effort and
      // must never delay or block the user's actual file save.
      triggerBlobDownload(blob, this.filename);

      // Persist a successful streamed download for offline reading. Cache
      // failure is intentionally non-fatal: the user still receives the file.
      let cached = false;
      try { cached = await cachePdf(this.book?.id, blob, {
        filename: this.filename,
        etag: metadata.etag,
        lastModified: metadata.lastModified
      }); } catch {}

      const result = {
        ok: true,
        state: DOWNLOAD_STATES.COMPLETED,
        bookId: this.book?.id ?? null,
        filename: this.filename,
        bytes: blob.size,
        totalBytes: finalTotalBytes,
        cached,
        metadata,
        elapsedMs: Date.now() - this.startedAt
      };
      this.setState(DOWNLOAD_STATES.COMPLETED, result);
      RETRYABLE.delete(this.book?.id);
      return result;
    } catch(err){
      if(err?.name === "AbortError"){
        const result = { ok: false, state: DOWNLOAD_STATES.CANCELLED, bookId: this.book?.id ?? null, filename: this.filename, ...this.lastProgress };
        this.setState(DOWNLOAD_STATES.CANCELLED, result);
        RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
        return result;
      }

      const result = {
        ok: false,
        state: DOWNLOAD_STATES.FAILED,
        bookId: this.book?.id ?? null,
        filename: this.filename,
        error: err
      };
      this.setState(DOWNLOAD_STATES.FAILED, result);
      if(err?.retryable !== false) {
        RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
      }
      throw err;
    }
  }

  handOffToBrowser(reason, metadata = {}){
    if(this.state === DOWNLOAD_STATES.CANCELLING || this.controller.signal.aborted){
      const result = { ok:false, state:DOWNLOAD_STATES.CANCELLED, mode:"handoff", reason, bookId:this.book?.id ?? null, filename:this.filename, ...this.lastProgress };
      this.setState(DOWNLOAD_STATES.CANCELLED, result);
      RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
      return Promise.resolve(result);
    }

    this.setState(DOWNLOAD_STATES.HANDING_OFF, {
      ...metadata,
      mode:"handoff",
      handoffReason:reason,
      sizeKnown:Number.isFinite(metadata.totalBytes),
      totalBytes:metadata.totalBytes ?? null,
      totalMegabytes:bytesToMegabytes(metadata.totalBytes),
      downloadedBytes:0,
      downloadedMegabytes:0,
      percentage:null
    });

    try {
      triggerDirectDownload(this.url, this.filename);
      const result = {
        ok:true,
        state:DOWNLOAD_STATES.HANDED_OFF,
        mode:"handoff",
        reason,
        bookId:this.book?.id ?? null,
        filename:this.filename,
        totalBytes:metadata.totalBytes ?? null,
        sizeKnown:Number.isFinite(metadata.totalBytes),
        elapsedMs:Date.now()-this.startedAt
      };
      this.setState(DOWNLOAD_STATES.HANDED_OFF, result);
      RETRYABLE.delete(this.book?.id);
      return Promise.resolve(result);
    } catch(err){
      const result={ok:false,state:DOWNLOAD_STATES.FAILED,mode:"handoff",reason,bookId:this.book?.id ?? null,filename:this.filename,error:err};
      this.setState(DOWNLOAD_STATES.FAILED,result);
      RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
      return Promise.reject(err);
    }
  }

  async readResponse(response, metadata){
    if(!response.body?.getReader){
      const blob = await response.blob();
      this.setState(DOWNLOAD_STATES.DOWNLOADING, {
        ...metadata,
        downloadedBytes: blob.size,
        downloadedMegabytes: bytesToMegabytes(blob.size),
        totalMegabytes: bytesToMegabytes(metadata.totalBytes || blob.size),
        percentage: metadata.totalBytes ? Math.min(100, (blob.size / metadata.totalBytes) * 100) : null,
        progressSupported: false
      });
      return blob;
    }

    const reader = response.body.getReader();
    const chunks = [];
    let downloadedBytes = 0;
    let lastEmitAt = 0;
    let lastSampleAt = this.startedAt || Date.now();
    let lastSampleBytes = 0;
    let smoothedSpeed = 0;
    const progressTotal = metadata.contentEncoding ? null : metadata.totalBytes;

    try{
      while(true){
        const {done, value} = await reader.read();
        if(done) break;
        if(value?.byteLength){
          chunks.push(value);
          downloadedBytes += value.byteLength;

          // Guard against a server sending more bytes than advertised.
          // Without this check a malformed response could keep growing the
          // in-memory Blob indefinitely.
          if(progressTotal && downloadedBytes > progressTotal){
            throw createDownloadError("The server sent more data than expected.", "RESPONSE_TOO_LARGE", false);
          }
        }

        const now = Date.now();
        if(now - lastEmitAt >= 100 || downloadedBytes === progressTotal){
          const elapsed = Math.max(1, now - lastSampleAt);
          const delta = downloadedBytes - lastSampleBytes;
          const instantSpeed = delta > 0 ? delta / (elapsed / 1000) : 0;
          if(instantSpeed > 0){
            smoothedSpeed = smoothedSpeed ? (smoothedSpeed * 0.7) + (instantSpeed * 0.3) : instantSpeed;
          }
          lastSampleAt = now;
          lastSampleBytes = downloadedBytes;
          lastEmitAt = now;

          const percentage = progressTotal ? Math.min(100, (downloadedBytes / progressTotal) * 100) : null;
          const remainingBytes = progressTotal ? Math.max(0, progressTotal - downloadedBytes) : null;
          const etaSeconds = smoothedSpeed > 0 && remainingBytes != null ? remainingBytes / smoothedSpeed : null;

          this.setState(DOWNLOAD_STATES.DOWNLOADING, {
            ...metadata,
            progressSupported: true,
            totalBytes: progressTotal,
            sizeKnown: Number.isFinite(progressTotal),
            downloadedBytes,
            downloadedMegabytes: bytesToMegabytes(downloadedBytes),
            totalMegabytes: bytesToMegabytes(progressTotal),
            percentage,
            speedBytesPerSecond: smoothedSpeed || null,
            etaSeconds
          });
        }
      }
    }catch(err){
      try { await reader.cancel(); } catch {}
      throw err;
    }

    const blob = new Blob(chunks, {type: metadata.contentType || "application/pdf"});
    if(progressTotal && !metadata.contentEncoding && blob.size !== progressTotal){
      throw createDownloadError("The PDF download was incomplete. Please try again.", "INCOMPLETE_RESPONSE", true);
    }
    const finalTotal = progressTotal || blob.size;
    this.setState(DOWNLOAD_STATES.DOWNLOADING, {
      ...metadata,
      progressSupported: true,
      totalBytes: finalTotal,
      sizeKnown: true,
      downloadedBytes: blob.size,
      downloadedMegabytes: bytesToMegabytes(blob.size),
      totalMegabytes: bytesToMegabytes(finalTotal),
      percentage: finalTotal ? Math.min(100, (blob.size / finalTotal) * 100) : null,
      speedBytesPerSecond: smoothedSpeed || null,
      etaSeconds: 0
    });
    return blob;
  }

  cancel(){
    if([
      DOWNLOAD_STATES.COMPLETED,
      DOWNLOAD_STATES.FAILED,
      DOWNLOAD_STATES.CANCELLED,
      DOWNLOAD_STATES.CANCELLING,
      DOWNLOAD_STATES.HANDING_OFF,
      DOWNLOAD_STATES.HANDED_OFF
    ].includes(this.state)) return false;

    // Give the UI a visible cancellation state before aborting the stream.
    // This is intentionally synchronous so the user immediately sees
    // "Cancelling…" instead of the status card disappearing.
    this.setState(DOWNLOAD_STATES.CANCELLING, {
      ...this.lastProgress,
      cancelRequestedAt: Date.now()
    });
    this.controller.abort();
    return true;
  }
}

export const downloadManager = {
  download(book, url, options = {}){
    if(!book?.id) return Promise.reject(new Error("Book id is required for download"));

    const existing = ACTIVE.get(book.id);
    if(existing) return existing.promise;

    const job = new DownloadJob(book, url, options);
    job.promise = job.run().finally(() => {
      if(ACTIVE.get(book.id) === job) ACTIVE.delete(book.id);
    });
    ACTIVE.set(book.id, job);
    return job.promise;
  },

  cancel(bookId){
    return ACTIVE.get(bookId)?.cancel() || false;
  },

  isDownloading(bookId){
    return ACTIVE.has(bookId);
  },

  getState(bookId){
    return ACTIVE.get(bookId)?.state || DOWNLOAD_STATES.IDLE;
  },

  getActiveJobs(){
    return Array.from(ACTIVE.values()).map(job => ({
      bookId: job.book?.id ?? null,
      filename: job.filename,
      state: job.state,
      progress: { ...job.lastProgress }
    }));
  },

  canRetry(bookId){
    return RETRYABLE.has(bookId) && !ACTIVE.has(bookId);
  },

  retry(bookId){
    if(ACTIVE.has(bookId)) return ACTIVE.get(bookId).promise;
    const request = RETRYABLE.get(bookId);
    if(!request) return Promise.reject(new Error("No retryable download"));
    if(typeof navigator !== "undefined" && navigator.onLine === false){
      const error=new Error("You appear to be offline.");
      error.code="OFFLINE";
      return Promise.reject(error);
    }
    RETRYABLE.delete(bookId);
    return this.download(request.book, request.url, request.options);
  },

  clearRetry(bookId){
    RETRYABLE.delete(bookId);
  },

  subscribe(listener){
    if(typeof listener !== "function") return () => {};
    SUBSCRIBERS.add(listener);
    return () => SUBSCRIBERS.delete(listener);
  }
};
