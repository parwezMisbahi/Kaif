const KEY="__KR_READER_NETWORK_MONITOR__";

function now(){return typeof performance?.now==="function"?performance.now():Date.now();}
function finiteNumber(v){const n=Number(v);return Number.isFinite(n)?n:null;}

export function createReaderNetworkMonitor({bookId,gatewayUrl,debug=false}={}){
  const startedAt=now();
  const gatewayOrigin=new URL(gatewayUrl,location.href).origin;
  const gatewayPath=new URL(gatewayUrl,location.href).pathname;
  const requests=[];
  const timings=[];
  let restored=false;
  let originalFetch=null;
  let observer=null;
  let lastProgress={loaded:0,total:null};

  const record=(item)=>{
    requests.push({atMs:Math.round(now()-startedAt),...item});
    if(requests.length>300)requests.shift();
  };

  const matches=(url)=>{
    try{
      const u=new URL(url,location.href);
      return u.origin===gatewayOrigin&&u.pathname===gatewayPath;
    }catch{return false;}
  };

  if(typeof PerformanceObserver!=="undefined"){
    try{
      observer=new PerformanceObserver(list=>{
        for(const entry of list.getEntries()){
          if(!matches(entry.name))continue;
          const transfer=finiteNumber(entry.transferSize);
          const encoded=finiteNumber(entry.encodedBodySize);
          const decoded=finiteNumber(entry.decodedBodySize);
          const timing={
            atMs:Math.round(now()-startedAt),
            name:entry.name,
            durationMs:Math.round(entry.duration),
            transferSize:transfer,
            encodedBodySize:encoded,
            decodedBodySize:decoded
          };
          timings.push(timing);
          if(timings.length>300)timings.shift();
        }
      });
      observer.observe({type:"resource",buffered:true});
    }catch{}
  }

  if(typeof window.fetch==="function"){
    originalFetch=window.fetch.bind(window);
    window.fetch=async(...args)=>{
      let url="";
      try{
        const input=args[0];
        url=typeof input==="string"?input:(input?.url||"");
      }catch{}
      if(!matches(url))return originalFetch(...args);
      const t0=now();
      try{
        const response=await originalFetch(...args);
        record({
          type:"fetch",
          status:response.status,
          ok:response.ok,
          range:args[1]?.headers?.Range||args[1]?.headers?.range||null,
          contentLength:finiteNumber(response.headers.get("content-length")),
          contentRange:response.headers.get("content-range"),
          acceptRanges:response.headers.get("accept-ranges"),
          rangeError:response.headers.get("x-kr-pdf-range-error"),
          cacheHit:false,
          durationMs:Math.round(now()-t0)
        });
        return response;
      }catch(error){
        record({type:"fetch-error",message:String(error?.message||error),durationMs:Math.round(now()-t0)});
        throw error;
      }
    };
  }

  const api={
    bookId,
    startedAt,
    recordProgress(loaded,total){
      const l=finiteNumber(loaded),t=finiteNumber(total);
      if(l!==null)lastProgress.loaded=Math.max(lastProgress.loaded,l);
      if(t!==null&&t>0)lastProgress.total=t;
    },
    snapshot(){
      const headerBytes=requests.reduce((sum,r)=>sum+(finiteNumber(r.contentLength)||0),0);
      const timingBytes=timings.reduce((sum,r)=>sum+(finiteNumber(r.transferSize)||0),0);
      return {
        bookId,
        elapsedMs:Math.round(now()-startedAt),
        requestCount:requests.filter(r=>r.type==="fetch").length,
        statuses:requests.filter(r=>r.type==="fetch").map(r=>r.status),
        partialResponses:requests.filter(r=>r.type==="fetch"&&r.status===206).length,
        fullResponses:requests.filter(r=>r.type==="fetch"&&r.status===200).length,
        headerContentLengthBytes:headerBytes,
        performanceTransferBytes:timingBytes,
        progressLoadedBytes:lastProgress.loaded,
        advertisedTotalBytes:lastProgress.total,
        requests:[...requests],
        timings:[...timings],
        rangeCache:{enabled:false,hits:0,misses:0,storedBytes:0}
      };
    },
    restore(){
      if(restored)return;
      restored=true;
      observer?.disconnect?.();
      if(originalFetch)window.fetch=originalFetch;
      try{delete window[KEY];}catch{window[KEY]=null;}
    },
    log(){
      if(!debug)return;
      console.info("[KR Reader Network]",api.snapshot());
    }
  };

  try{window[KEY]=api;}catch{}
  if(debug)console.info("[KR Reader Network] measurement enabled",{bookId});
  return api;
}
