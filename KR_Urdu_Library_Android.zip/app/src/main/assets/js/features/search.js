const URDU_MARKS = /[ًٌٍَُِّْـ]/g;
const normalizedBookCache = new WeakMap();
const VARIANT_MAP = /[يى]/g;

export function normalize(value = "") {
  return String(value)
    .toLowerCase()
    .replace(URDU_MARKS, "")
    .replace(VARIANT_MAP, "ی")
    .replace(/[ك]/g, "ک")
    .replace(/[ۀہ]/g, "ہ")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ی")
    .replace(/ـ/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function getIndexedBook(book) {
  let indexed = normalizedBookCache.get(book);
  if (indexed) return indexed;

  const title = normalize([book?.title, book?.titleEn].filter(Boolean).join(" "));
  const author = normalize(book?.author || "");
  const description = normalize(book?.description || "");
  const keywordList = Array.isArray(book?.keywords)
    ? book.keywords.map(normalize).filter(Boolean)
    : [];
  const keywords = keywordList.join(" ");

  indexed = {
    title,
    author,
    description,
    keywords,
    keywordList,
    haystack: [title, author, description].filter(Boolean).join(" ")
  };
  normalizedBookCache.set(book, indexed);
  return indexed;
}

export function searchBooks(books = [], query = "") {
  const normalizedQuery = normalize(query);
  if (!normalizedQuery) return books;

  const tokens = normalizedQuery.split(/\s+/).filter(Boolean);

  return books.map((book, index) => {
    const { title, author, description, keywords, keywordList, haystack } = getIndexedBook(book);

    // A keyword is searchable when the complete normalized keyword equals a
    // query token. This mirrors the server-side `keywords.cs.{token}` filter.
    const matchesToken = token =>
      haystack.includes(token) || keywordList.includes(token);

    if (!tokens.every(matchesToken)) return null;

    let score = 0;
    if (title === normalizedQuery) score += 100;
    if (title.startsWith(normalizedQuery)) score += 60;
    if (title.includes(normalizedQuery)) score += 35;
    if (author.includes(normalizedQuery)) score += 25;
    if (keywords.includes(normalizedQuery)) score += 15;
    tokens.forEach(token => {
      if (title.includes(token)) score += 6;
    });

    return { book, score, index };
  })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map(x => x.book);
}
