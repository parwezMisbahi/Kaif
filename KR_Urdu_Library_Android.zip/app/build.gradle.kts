plugins {
  alias(libs.plugins.android.application)
}

// Values can be overridden from the GitHub workflow (-PappId=... -PappName=...)
val appIdValue = (findProperty("appId") as String?) ?: "com.krurdulibrary.app"
val appNameValue = (findProperty("appName") as String?) ?: "KR Urdu Library"

android {
  namespace = "com.krurdulibrary.app"
  compileSdk = 36

  defaultConfig {
    applicationId = appIdValue
    minSdk = 24
    targetSdk = 36
    versionCode = (findProperty("verCode") as String?)?.toIntOrNull() ?: 1
    versionName = "1.0.0"
    manifestPlaceholders["appLabel"] = appNameValue
  }

  // Fixed signing key (created once, committed to the repo, and reused) so every new
  // build installs as an UPDATE over the previous one without losing app data.
  val ks = rootProject.file("krlibrary.jks")
  signingConfigs {
    if (ks.exists()) {
      create("krlibrary") {
        storeFile = ks
        storePassword = "krlibrary123"
        keyAlias = "krlibrary"
        keyPassword = "krlibrary123"
      }
    }
  }

  buildTypes {
    debug {
      if (ks.exists()) signingConfig = signingConfigs.getByName("krlibrary")
    }
    release {
      if (ks.exists()) signingConfig = signingConfigs.getByName("krlibrary")
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
}

dependencies {
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.appcompat)
}
